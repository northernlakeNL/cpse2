var indexSectionsWithContent =
{
  0: "bcdfglmopsuv",
  1: "bflops",
  2: "m",
  3: "bdglmpsuv",
  4: "cm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

