var searchData=
[
  ['ball_0',['Ball',['../class_ball.html',1,'Ball'],['../class_ball.html#abcb638a82cb4c22fc8dddfe48f8c6d72',1,'Ball::Ball()']]]
];
