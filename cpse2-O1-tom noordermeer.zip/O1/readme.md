# CPSE2 Herkansing 2023/24 - Opdracht 1 - Tom Noordermeer

Dit is een project voor CPSE2, gemaakt door Tom Noordermeer. Het project is bedoeld voor Opdracht 1 van het vak CPSE2.

## Projectinformatie

- Type: BMPTK project
- Configuratiebestand: N.V.T.
- Commandline-parameters: N.V.T.
- Handleiding Pong:
    - De linker speler kan bewegen met de W en S toetsen.
    - De rechter speler kan bewegen met de pijltjestoetsen, omhoog en omlaag.
    - De bal beweegt automatisch.
